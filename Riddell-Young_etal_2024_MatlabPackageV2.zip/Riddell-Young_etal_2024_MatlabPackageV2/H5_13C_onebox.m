%One box model 13C-CH4 test for H5 using the box model of Tans et al., 1997

clear all
close all
format longG

%Load Data
%Load CFA data and smooth: Smooth via moving average to remove measurement
%noise and make the record better reflect the atmopsheric smoothing
%observed in ice cores. Will need to think about this later in terms of C13
%and rates of change
CFA = xlsread('Rhodes_CFA.xlsx');   %Rhodes et al., 2015
mdlstart = 18379;
mdlend = 19826;
Depth = CFA(mdlstart:mdlend,1);
Depth2 = CFA(:,1);
Depth = flip(Depth);
GasAge = CFA(mdlstart:mdlend,5);
GasAge = flip(GasAge);
CFA_CH4 = CFA(mdlstart:mdlend,4);
CFA_CH4 = flip(CFA_CH4)*1.01;   %Increase concentration by 1% to represent global CH4 with a 2% rIPD;
%Smooth 10 years 
CFA_CH4_10 = smooth(CFA_CH4);
%Smooth 20 years 
CFA_CH4_20 = smooth(CFA_CH4,10);
%Smooth 30 years
CFA_CH4_30 = smooth(CFA_CH4,15);

%interpolate CFA data onto 1 year time resolution
GasAgeNew = [46757:1:49651]';
GasAgeNew = flip(GasAgeNew);
CFA_CH4 = interp1(GasAge,CFA_CH4,GasAgeNew);
CFA_CH4_10 = interp1(GasAge,CFA_CH4_10,GasAgeNew);
CFA_CH4_20 = interp1(GasAge,CFA_CH4_20,GasAgeNew);
CFA_CH4_30 = interp1(GasAge,CFA_CH4_30,GasAgeNew);

%Load H5 13C data
H5data = xlsread('H5_13C_Diff.xlsx');

MeanDepth = flip(H5data(1:43,1));
C13Raw = flip(H5data(1:43,2));
C13DiffRaw =  flip(H5data(1:43,4));
C13Diff10 =  flip(H5data(1:43,5));
C13Diff20 = flip(H5data(1:43,6));
C13Diff30 =  flip(H5data(1:43,7));
C13_stdev = flip(H5data(1:43,11));
%Interpolate age
MeanAge = interp1(Depth,GasAge,MeanDepth);

%Average replicates to reduce noise
%Replicates at samples 12 and 13
%Replicates at samples 17 and 18
%Replicates at samples 26 and 27
%Replicates at samples 33 and 34
%Replicates at samples 41 and 42
MeanDepth = [MeanDepth(1:11);mean(MeanDepth(12:13));MeanDepth(14:16);mean(MeanDepth(17:18));MeanDepth(19:25);mean(MeanDepth(26:27));MeanDepth(28:32);mean(MeanDepth(33:34));MeanDepth(35:40);mean(MeanDepth(41:42));MeanDepth(43)];
MeanAge = [MeanAge(1:11);mean(MeanAge(12:13));MeanAge(14:16);mean(MeanAge(17:18));MeanAge(19:25);mean(MeanAge(26:27));MeanAge(28:32);mean(MeanAge(33:34));MeanAge(35:40);mean(MeanAge(41:42));MeanAge(43)];
C13Raw = [C13Raw(1:11);mean(C13Raw(12:13));C13Raw(14:16);mean(C13Raw(17:18));C13Raw(19:25);mean(C13Raw(26:27));C13Raw(28:32);mean(C13Raw(33:34));C13Raw(35:40);mean(C13Raw(41:42));C13Raw(43)];
C13DiffRaw = [C13DiffRaw(1:11);mean(C13DiffRaw(12:13));C13DiffRaw(14:16);mean(C13DiffRaw(17:18));C13DiffRaw(19:25);mean(C13DiffRaw(26:27));C13DiffRaw(28:32);mean(C13DiffRaw(33:34));C13DiffRaw(35:40);mean(C13DiffRaw(41:42));C13DiffRaw(43)];
C13Diff10 = [C13Diff10(1:11);mean(C13Diff10(12:13));C13Diff10(14:16);mean(C13Diff10(17:18));C13Diff10(19:25);mean(C13Diff10(26:27));C13Diff10(28:32);mean(C13Diff10(33:34));C13Diff10(35:40);mean(C13Diff10(41:42));C13Diff10(43)];
C13Diff20 = [C13Diff20(1:11);mean(C13Diff20(12:13));C13Diff20(14:16);mean(C13Diff20(17:18));C13Diff20(19:25);mean(C13Diff20(26:27));C13Diff20(28:32);mean(C13Diff20(33:34));C13Diff20(35:40);mean(C13Diff20(41:42));C13Diff20(43)];
C13Diff30 = [C13Diff30(1:11);mean(C13Diff30(12:13));C13Diff30(14:16);mean(C13Diff30(17:18));C13Diff30(19:25);mean(C13Diff30(26:27));C13Diff30(28:32);mean(C13Diff30(33:34));C13Diff30(35:40);mean(C13Diff30(41:42));C13Diff30(43)];
C13_stdev = [C13_stdev(1:11);mean(C13_stdev(12:13));C13_stdev(14:16);mean(C13_stdev(17:18));C13_stdev(19:25);mean(C13_stdev(26:27));C13_stdev(28:32);mean(C13_stdev(33:34));C13_stdev(35:40);mean(C13_stdev(41:42));C13_stdev(43)];


%Monte carlo simulation that incorporates C13 uncertainty into model
for k = 1:1000
    
    
    %incorporate uncertainty 
    numbah = zeros(length(C13Diff20),1);
    for pp = 1:length(C13Diff20)
        numbah(pp) = normrnd(0,1);
    end 
    C13DiffRawb = C13DiffRaw+C13_stdev.*numbah;
    C13Diff10b = C13Diff10+C13_stdev.*numbah;
    C13Diff20b = C13Diff20+C13_stdev.*numbah;
    C13Diff30b = C13Diff30+C13_stdev.*numbah;

%Interpolate (gaussian) onto CFA age scale
%C13RawS = smooth(C13Raw,3);
C13RawI = interp1(MeanAge,C13Raw,GasAgeNew,'pchip');
%C13DiffRawS = smooth(C13DiffRaw,3);
C13DiffRawI = interp1(MeanAge,C13DiffRawb,GasAgeNew,'pchip');
%C13Diff10S = smooth(C13Diff10,3);
C13Diff10I = interp1(MeanAge,C13Diff10b,GasAgeNew,'pchip');
%C13Diff20S = smooth(C13Diff20,3);
C13Diff20I = interp1(MeanAge,C13Diff20b,GasAgeNew,'pchip');
%C13Diff30S = smooth(C13Diff30,3);
C13Diff30I = interp1(MeanAge,C13Diff30b,GasAgeNew,'pchip');
%Interpolate original data without random error added
C13DiffRawI = interp1(MeanAge,C13DiffRaw,GasAgeNew,'pchip');
C13Diff10Ib = interp1(MeanAge,C13Diff10,GasAgeNew,'pchip');
C13Diff20Ib = interp1(MeanAge,C13Diff20,GasAgeNew,'pchip');
C13Diff30Ib = interp1(MeanAge,C13Diff30,GasAgeNew,'pchip');

%Constants for model
C13Std = .0112020968;                 %standard for D-H isotopic ratio
Watm = 28.96;                         %Molecular weight of atmosphere (g/mole)                           
Matm = 5.15*10^21;                    %Mass of atmosphere (g) 
Sink = 1.006;                         %Kept stable for now. Likely varies. Could do sensitivity tests.
Lifetime = 9;
C13start = -45;  
PT = 2.815*1.01;                      %Conversion factor for ppb to Tg using the molar mass of the atmosphere. Muliplied by 50% of the assumed IPD
%Conversion from delta notation to 13C/(13C + 12C)
Ratio2 = @(y) ((y/1000 + 1)*C13Std)./((y/1000 + 1)*C13Std + 1);

%% 1 box model

for i = 1:(length(CFA_CH4)-1)
    SourceRaw = CFA_CH4(i+1)*PT - CFA_CH4(i)*PT + CFA_CH4(i)*PT/(Lifetime);
    sumSourceRaw(i,1) = SourceRaw;
    Source10 = CFA_CH4_10(i+1)*PT - CFA_CH4_10(i)*PT + CFA_CH4_10(i)*PT/(Lifetime);
    sumSource10(i,1) = Source10;
    Source20 = CFA_CH4_20(i+1)*PT - CFA_CH4_20(i)*PT + CFA_CH4_20(i)*PT/(Lifetime);
    sumSource20(i,1) = Source20;
    Source30 = CFA_CH4_30(i+1)*PT - CFA_CH4_30(i)*PT + CFA_CH4_30(i)*PT/(Lifetime);
    sumSource30(i,1) = Source30;
end

%% Calculate source signature

%1-box model for Carbon Stable isotopes 

%Calculate n13C (number of 13C moles in atmosphere based on isotopic signature)
C13DiffRawI2 = Ratio2(C13DiffRawI);
n13C_Raw = C13DiffRawI2.*CFA_CH4*PT;
C13Diff10I2 = Ratio2(C13Diff10I);
n13C_10 = C13Diff10I2.*CFA_CH4_10*PT;
C13Diff20I2 = Ratio2(C13Diff20I);
n13C_20 = C13Diff20I2.*CFA_CH4_20*PT;
C13Diff30I2 = Ratio2(C13Diff30I);
n13C_30 = C13Diff30I2.*CFA_CH4_30*PT;
alpha_13C = 1/Sink;

%Sensitivity tests
%What is the d13Catm of the 1 box if the source signature remains constant 
R13C = Ratio2(-50);
n13C = Ratio2(-44.25)*CFA_CH4_30(1)*PT;
%Create theoretical stable atm 13C
C13_Th = -44*ones(length(CFA_CH4),1);
C13_Th2 = Ratio2(C13_Th);
n13C_Th = C13_Th2.*CFA_CH4_30*PT;

for j = 1:1:(length(CFA_CH4)-1)
    %Calculation of source 13C ratio for theoretical scenario where d13C-atm is stable
    R13C_Th = (n13C_Th(j+1) -  n13C_Th(j) + n13C_Th(j)*alpha_13C/(Lifetime))/sumSource30(j);
    sumR13C_Th(j,1) = R13C_Th;

    %Calculation of source 13C ratio for unsmoothed data
    R13C_raw = (n13C_Raw(j+1) -  n13C_Raw(j) + n13C_Raw(j)*alpha_13C/(Lifetime))/sumSourceRaw(j);
    sumR13C_raw(j,1) = R13C_raw;

    %Calculation of source 13C ratio for 10 year smoothed data
    R13C_10 = (n13C_10(j+1) -  n13C_10(j) + n13C_10(j)*alpha_13C/(Lifetime))/sumSource10(j);
    sumR13C_10(j,1) = R13C_10;

    %Calculation of source 13C ratio for 20 year smoothed data
    R13C_20 = (n13C_20(j+1) -  n13C_20(j) + n13C_20(j)*alpha_13C/(Lifetime))/sumSource20(j);
    sumR13C_20(j,1) = R13C_20;

    %Calculation of source 13C ratio for 30 year smoothed data
    R13C_30 = (n13C_30(j+1) -  n13C_30(j) + n13C_30(j)*alpha_13C/(Lifetime))/sumSource30(j);
    sumR13C_30(j,1) = R13C_30;

    %Calculation of atmospheric d13C for stable source signature
    n13C = n13C + R13C*sumSource30(j) - n13C*(alpha_13C)/Lifetime;
    sum13Cn(j,1) = n13C/PT;

end

%calculate delta13C of source
d13C_raw(:,k) = (sumR13C_raw - C13Std + sumR13C_raw*C13Std)./((C13Std - sumR13C_raw*C13Std)/1000);
d13C_10(:,k) = (sumR13C_10 - C13Std + sumR13C_10*C13Std)./((C13Std - sumR13C_10*C13Std)/1000);
d13C_20(:,k) = (sumR13C_20 - C13Std + sumR13C_20*C13Std)./((C13Std - sumR13C_20*C13Std)/1000);
d13C_30(:,k) = (sumR13C_30 - C13Std + sumR13C_30*C13Std)./((C13Std - sumR13C_30*C13Std)/1000);
d13C_Th(:,k) = (sumR13C_Th - C13Std + sumR13C_Th*C13Std)./((C13Std - sumR13C_Th*C13Std)/1000);
%Calculate 13C
delta13C_CH4 = ((sum13Cn./(CFA_CH4_30(2:end) - sum13Cn))/C13Std - 1)*1000;
% d13C_Thb = (sumR13C_Th / C13Std - 1) * 1000;
% d13C_10b = (sumR13C_10 / C13Std - 1) * 1000;
% d13C_30b = (sumR13C_30 / C13Std - 1) * 1000;

end

%Calculate mean and standard deviation for each smoothing scenario
d13C_raw_mean = mean(d13C_raw,2);
d13C_raw_std = std(d13C_raw,[],2);
d13C_10_mean = mean(d13C_10,2);
d13C_10_std = std(d13C_10,[],2);
d13C_20_mean = mean(d13C_20,2);
d13C_20_std = std(d13C_20,[],2);
d13C_30_mean = mean(d13C_30,2);
d13C_30_std = std(d13C_30,[],2);
d13C_Th_mean = mean(d13C_Th,2);
d13C_Th_std = std(d13C_Th,[],2);

%% Plot source strength and interpolated delta13C-CH4 record

figure (1) 
yyaxis left
aa = plot (GasAgeNew,CFA_CH4);
hold on 
yyaxis right
a = plot (GasAgeNew(1:(end-1)),sumSourceRaw,'LineStyle','-','color','#A2142F');
hold on
b = plot (GasAgeNew(1:(end-1)),sumSource10,'LineStyle','-','color','#0072BD');
hold on
c = plot (GasAgeNew(1:(end-1)),sumSource20,'LineStyle','-','color','#77AC30');
hold on
d = plot (GasAgeNew(1:(end-1)),sumSource30,'LineStyle','-','color','#EDB120');
legend([aa a b c d],'CFA Data (unsmoothed)','Source (unsmoothed)','Source (10 yr smooth)','Source (20 yr smooth)','Source (30 yr smooth)')


figure (2)
yyaxis left
a = plot (GasAgeNew,CFA_CH4);
hold on 
yyaxis right
b = plot(GasAgeNew,C13DiffRawI,'LineStyle','-','color','#A2142F');
hold on 
c = plot(GasAgeNew,C13Diff10I,'LineStyle','-','color','#0072BD');
hold on 
d = plot(GasAgeNew,C13Diff20I,'LineStyle','-','color','#77AC30');
hold on 
e = plot(GasAgeNew,C13Diff30I,'LineStyle','-','color','#EDB120');
hold on 
f = plot(GasAgeNew(2:(end-1)),delta13C_CH4(2:end),'LineStyle','-','color','#000000','Marker','none');
legend([a b c d e f],'CFA Data (unsmoothed)','Diff (unsmoothed)','Diff (10 yr smooth)','Diff (20 yr smooth)','Diff (30 yr smooth)','Expected d13C w/const. src')


figure (3)
yyaxis left
a = plot (GasAgeNew,CFA_CH4);
hold on 
yyaxis right
b = plot(GasAgeNew(1:(end-1)),d13C_raw_mean,'LineStyle','-','color','#A2142F');
hold on
c = plot(GasAgeNew(1:(end-1)),d13C_10_mean,'LineStyle','-','color','#0072BD');
hold on
d = plot(GasAgeNew(1:(end-1)),d13C_20_mean,'LineStyle','-','color','#77AC30');
hold on
e = plot(GasAgeNew(1:(end-1)),d13C_30_mean,'LineStyle','-','color','#EDB120');
hold on
f = plot(GasAgeNew(1:(end-1)),d13C_Th_mean,'LineStyle','-','color','#000000','Marker','none');
legend([a b c d e f],'CFA Data (unsmoothed)','13C-Src (unsmoothed)','13C-Src (10 yr smooth)','13C-Src (20 yr smooth)','13C-Src (30 yr smooth)','Expected 13C-Src w/const. d13C-atm')

%% Calculate source strengths for each major source category

%First, define 13C of sources (using bock et al., 2017 data)
F_13C = -44;                       %Fossil source signature
F_13C_stdev = .4; % 0.4 Based on Bock et al., 2017. Or 10.7 based on Sherwood et al., 2017
BB_13C = -22;                      %Biomass Burning source signature
BB_13C_stdev = 1.8; % 1.8 Based on Bock et al., 2017. Or 4.8 based on Sherwood et al., 2017
Mic_13C = -60;                     %Microbial source signature 
Mic_13C_stdev = 1.5; % 1.5 Based on Bock et al., 2017.  Or 6.2 based on Sherwood et al., 2017

%Define strength of fossil source: Big assumption
Sf = 2.5;                          %Tg yr-1 *Based on Dyonisius et al., 2020
Sf_std = 1.3;                          %Tg yr-1 *Based on Dyonisius et al., 2020

%Monte carlo error propagation using uncertainties of total source and
%individual source uncertainties. This ensures that analytical uncertainty
%is added to each timestep, but source signature is added to the whole time
%series for each iteration. The latter is important because we're seeing
%how sensitive our analyses are to uncertainties in source signatures, not
%their change over time.
for m = 1:1000
    %incorporate uncertainty 
    n1 = zeros(length(d13C_20_mean),1);
    for pp = 1:length(d13C_20_mean)
        n1(pp) = normrnd(0,1);
    end 
    F_13Cb = F_13C+normrnd(0,1)*F_13C_stdev;
    Sfb = Sf+normrnd(0,1,[length(d13C_20_mean), 1])*Sf_std;
    Sfb(Sfb < 0) = 0;
    BB_13Cb = BB_13C+normrnd(0,1)*BB_13C_stdev;
    Mic_13Cb = Mic_13C+normrnd(0,1)*Mic_13C_stdev;
    d13C_raw_meanB = d13C_raw_mean+n1.*d13C_raw_std;
    d13C_10_meanB = d13C_10_mean+n1.*d13C_10_std;
    d13C_20_meanB = d13C_20_mean+n1.*d13C_20_std;
    d13C_30_meanB = d13C_30_mean+n1.*d13C_30_std;

%Calculate Smic for each timestep

    %Unsmoothed data
    SmicRaw = (sumSourceRaw.*d13C_raw_meanB - BB_13Cb*(sumSourceRaw - Sf) - F_13Cb*Sf) / (Mic_13Cb - BB_13Cb);
    SbbRaw = sumSourceRaw - SmicRaw - Sf;
    SmicSumRaw(:,m) = SmicRaw;
    SbbSumRaw(:,m) = SbbRaw;
    %10 year smooth
    Smic10 = (sumSource10.*d13C_10_meanB - BB_13Cb*(sumSource10 - Sf) - F_13Cb*Sf) / (Mic_13Cb - BB_13Cb);
    Sbb10 = sumSource10 - Smic10 - Sf;
    SmicSum10(:,m) = Smic10;
    SbbSum10(:,m) = Sbb10;
    %20 year smooth
    Smic20 = (sumSource20.*d13C_20_meanB - BB_13Cb*(sumSource20 - Sfb) - F_13Cb*Sfb) / (Mic_13Cb - BB_13Cb);
    Sbb20 = sumSource20 - Smic20 - Sfb;
    SmicSum20(:,m) = Smic20;
    SbbSum20(:,m) = Sbb20;
        %Calculate relative change for by defining 0 point for each iteration
        SmicSum20R(:,m) = Smic20 - mean(Smic20);
        SbbSum20R(:,m) = Sbb20 - mean(Sbb20);
    %30 year smooth 
    Smic30 = (sumSource30.*d13C_30_meanB - BB_13Cb*(sumSource30 - Sf) - F_13Cb*Sf) / (Mic_13Cb - BB_13Cb);
    Sbb30 = sumSource30 - Smic30 - Sf;
    SmicSum30(:,m) = Smic30;
    SbbSum30(:,m) = Sbb30;
end

%Calculate mean and stdevs or monte carlo iteration
SmicRaw_mean = mean(SmicSumRaw,2);
SmicRaw_std = std(SmicSumRaw,[],2);
SbbRaw_mean = mean(SbbSumRaw,2);
SbbRaw_std = std(SbbSumRaw,[],2);
Smic10_mean = mean(SmicSum10,2);
Smic10_std = std(SmicSum10,[],2);
Sbb10_mean = mean(SbbSum10,2);
Sbb10_std = std(SbbSum10,[],2);
Smic20_mean = mean(SmicSum20,2);
Smic20_std = std(SmicSum20,[],2);
Sbb20_mean = mean(SbbSum20,2);
Sbb20_std = std(SbbSum20,[],2);
Smic30_mean = mean(SmicSum30,2);
Smic30_std = std(SmicSum30,[],2);
Sbb30_mean = mean(SbbSum30,2);
Sbb30_std = std(SbbSum30,[],2);

% Relative change! 
Smic20_meanR = mean(SmicSum20R,2);
Smic20_stdR = std(SmicSum20R,[],2);
Sbb20_meanR = mean(SbbSum20R,2);
Sbb20_stdR = std(SbbSum20R,[],2);


figure (4)
yyaxis left
a = plot (GasAgeNew,CFA_CH4);
hold on 
yyaxis right
%for n = 1:length(Sf)
    plot (GasAgeNew(1:(end-1)),SbbRaw_mean,'LineStyle','-.','color','red','LineWidth',1,'Marker','none');
    hold on    
    plot (GasAgeNew(1:(end-1)),Sbb10_mean,'LineStyle','--','color','red','LineWidth',1,'Marker','none');
    hold on
    b = plot (GasAgeNew(1:(end-1)),Sbb20_mean,'LineStyle','-','color','red','LineWidth',1,'Marker','none');
    hold on
    plot (GasAgeNew(1:(end-1)),Sbb30_mean,'LineStyle',':','color','red','LineWidth',1,'Marker','none');
    hold on
    plot (GasAgeNew(1:(end-1)),SmicRaw_mean,'LineStyle','-.','color','green','LineWidth',1,'Marker','none');
    hold on
    plot (GasAgeNew(1:(end-1)),Smic10_mean,'LineStyle','--','color','green','LineWidth',1,'Marker','none');
    hold on
    c = plot (GasAgeNew(1:(end-1)),Smic20_mean,'LineStyle','-','color','green','LineWidth',1,'Marker','none');
    hold on
    plot (GasAgeNew(1:(end-1)),Smic30_mean,'LineStyle',':','color','green','LineWidth',1,'Marker','none');
    hold on
%end
legend([a b c],'CFA (unsmoothed)','Biomass Burning','Microbial')

figure (10)
plot (GasAgeNew(1:(end-1)),(Sbb20_mean+1*Sbb20_std))
hold on
plot (GasAgeNew(1:(end-1)),(Sbb20_mean-1*Sbb20_std))

%% Calculate the theoretical change in 13C mic and BB constant BB and F

% % % %Only vary microbial source strength and isotopic signature 
% % % C13_mic_vary2 = (sumSource20.*d13C_20_mean - 20*BB_13C - 30*F_13C ) ./ (sumSource20 - 50);
% % % mic_source = sumSource20 - 50;
% % % %Only vary microbial source strength and BB isotopic signature 
% % % C13_BB_vary = (sumSource20.*d13C_20_mean - (sumSource20-50)*Mic_13C - 30*F_13C ) / 20;
% % % %
% % % % Fist calculate with proportional changes in all sources (unlikely) 
% % % % C13_mic_vary1 = (sumSource20.*d13C_20_mean - 0.2*sumSource20.*BB_13C - 0.2*sumSource20.*F_13C ) ./ (0.6*sumSource20);
% % % %
% % % % figure (7) %plot of microbial source strength vs measured 13C data
% % % % yyaxis left 
% % % % plot (GasAgeNew(1:(end-1)),mic_source);
% % % % hold on
% % % % yyaxis right
% % % % plot(GasAgeNew,C13Diff20I,'LineStyle','-','color','#77AC30');
% % % % hold on 
% % % 
% % % %Now, calculate how the ratio of C3:C4 would need to change to explain
% % % %this.
% % % %define some constants:
% % % C4_13C = -50;%-51;
% % % C3_13C = -60;%-63;
% % % Boreal_13C = -68;
% % % Boreal_source = 35;  % Needed to changge this to get realistic ratios of C4 to C3. It's 20 Tg for H4.
% % % %Calculate C3 and C4 microbial strength:
% % % C3_trop = (sumSource20.*d13C_20_mean - 20*BB_13C - 30*F_13C - Boreal_source*Boreal_13C - sumSource20*C4_13C + 20*C4_13C + 30*C4_13C + Boreal_source*C4_13C) / (C3_13C - C4_13C);
% % % C4_trop = sumSource20 - 20 - 30 - Boreal_source - C3_trop;
% % % C3 = (sumSource20.*d13C_20_mean - 20*BB_13C - 30*F_13C - sumSource20*C4_13C + 20*C4_13C + 30*C4_13C) / (C3_13C - C4_13C);
% % % C4 = sumSource20 - 20 - 30 - C3;
% % % C3_C4 = C3 ./ C4;
% % % C3_prop = C3 ./ (sumSource20 - 50); %proportion of all microbial emissions that are C4
% % % C3_prop_trop = C3_trop ./ (sumSource20 - 50 - Boreal_source); %proportion of all microbial emissions that are C4
% % % 
% % % figure (20) 
% % % plot (GasAgeNew(1:(end-1)),C3_trop,'b');
% % % hold on 
% % % plot (GasAgeNew(1:(end-1)),C4_trop,'r');
% % % hold on

%Only vary microbial source strength and isotopic signature 
C13_mic_vary2 = (sumSource20.*d13C_20_mean - 30*BB_13C - 5*F_13C ) ./ (sumSource20 - 35);
mic_source = sumSource20 - 35;
%Only vary microbial source strength and BB isotopic signature 
C13_BB_vary = (sumSource20.*d13C_20_mean - (sumSource20-35)*Mic_13C - 30*F_13C ) / 30;
%
% Fist calculate with proportional changes in all sources (unlikely) 
% C13_mic_vary1 = (sumSource20.*d13C_20_mean - 0.2*sumSource20.*BB_13C - 0.2*sumSource20.*F_13C ) ./ (0.6*sumSource20);
%
% figure (7) %plot of microbial source strength vs measured 13C data
% yyaxis left 
% plot (GasAgeNew(1:(end-1)),mic_source);
% hold on
% yyaxis right
% plot(GasAgeNew,C13Diff20I,'LineStyle','-','color','#77AC30');
% hold on 

%Now, calculate how the ratio of C3:C4 would need to change to explain
%this.
%define some constants:
C4_13C = -52;%-51;
C3_13C = -64;%-63;
Boreal_13C = -68;
Boreal_source = 20;
%Calculate C3 and C4 microbial strength:
C3_trop = (sumSource20.*d13C_20_mean - 30*BB_13C - 5*F_13C - Boreal_source*Boreal_13C - sumSource20*C4_13C + 30*C4_13C + 5*C4_13C + Boreal_source*C4_13C) / (C3_13C - C4_13C);
C4_trop = sumSource20 - 20 - 30 - Boreal_source - C3_trop;
C3 = (sumSource20.*d13C_20_mean - 30*BB_13C - 5*F_13C - sumSource20*C4_13C + 30*C4_13C + 5*C4_13C) / (C3_13C - C4_13C);
C4 = sumSource20 - 30 - 5 - C3;
C3_C4 = C3 ./ C4;
C3_prop = C3 ./ (sumSource20 - 35); %proportion of all microbial emissions that are C4
C3_prop_trop = C3_trop ./ (sumSource20 - 35 - Boreal_source); %proportion of all microbial emissions that are C4

figure (20) 
plot (GasAgeNew(1:(end-1)),C3_trop,'b');
hold on 
plot (GasAgeNew(1:(end-1)),C4_trop,'r');
hold on


%% Calcalate theoretical dD-CH4 

%Constants for model
DStd = .00015576;                     %standard for D-H isotopic ratio
Watm = 28.96;                         %Molecular weight of atmosphere (g/mole)                           
Matm = 5.15*10^21;                    %Mass of atmosphere (g) 
Sink = 1.276;                         %Kept stable for now. Likely varies. Could do sensitivity tests.
alpha_D = 1/Sink;
Lifetime = 9;
dDstart = -80;  
%Conversion from delta notation to 13C/(13C + 12C)
Ratio2D = @(y) ((y/1000 + 1)*DStd)./((y/1000 + 1)*DStd + 1);
FF_D = Ratio2D(-185);                      %Fossil source signature (Fujita et al., 2020)
BB_D = Ratio2D(-210);                      %Biomass Burning source signature (Fujita et al., 2020)
Mic_D = Ratio2D(-320);                     %Microbial source signature (Fujita et al., 2020)

total = Smic20_mean + Sf + Sbb20_mean;
%Concentration 1 box model
CH4n = CFA_CH4(1,1)*PT;
for i = 1:length(GasAgeNew(1:(end-1)))
    CH4n = CH4n + total(i) - CH4n/(Lifetime);
    sumCH4(i,1) = CH4n/PT;
end

%1-box model for Deuterium Stable isotopes 
RD = (Smic20_mean * Mic_D + Sf * FF_D + Sbb20_mean * BB_D)./(total);
dDstart2 = Ratio2D(dDstart);
nD = dDstart2*CFA_CH4(1,1)*PT;
for i = 1:length(GasAgeNew(1:(end-1)))
     nD = nD + RD(i)*total(i) - nD*(alpha_D)/(Lifetime);
     sumDn(i,1) = nD/PT;
end

%Calculate dD
dD_CH4_Cff = ((sumDn./(sumCH4 - sumDn))/DStd - 1)*1000;


%% Repeat same assuming constant biomass burning 

bbS = 25;

%Monte carlo error propagation using uncertainties of total source and
%individual source uncertainties
for m = 1:1000
    number = normrnd(0,1);
    number2 = normrnd(0,1);
    number3 = normrnd(0,1);
    number4 = normrnd(0,1);
    F_13Cb = F_13C+number*F_13C_stdev;
    BB_13Cb = BB_13C+number2*BB_13C_stdev;
    Mic_13Cb = Mic_13C+number3*Mic_13C_stdev;
    d13C_raw_meanB = d13C_raw_mean+number4*d13C_raw_std;
    d13C_10_meanB = d13C_10_mean+number4*d13C_10_std;
    d13C_20_meanB = d13C_20_mean+number4*d13C_20_std;
    d13C_30_meanB = d13C_30_mean+number4*d13C_30_std; 
%     F_13Cb = normrnd(F_13C,F_13C_stdev);
%     BB_13Cb = normrnd(BB_13C,BB_13C_stdev);
%     Mic_13Cb = normrnd(Mic_13C,Mic_13C_stdev);
%     d13C_raw_meanB = normrnd(d13C_raw_mean,d13C_raw_std);
%     d13C_10_meanB = normrnd(d13C_10_mean,d13C_10_std);
%     d13C_20_meanB = normrnd(d13C_20_mean,d13C_10_std);
%     d13C_30_meanB = normrnd(d13C_30_mean,d13C_10_std);

%Calculate Smic and FF for each timestep

    fS10 = (sumSource10.*d13C_10_mean - Mic_13C*(sumSource10 - bbS) - BB_13C*bbS) / (F_13C - Mic_13C);
    micS10 = sumSource10 - bbS - fS10;
    SmicSum10F(:,m) = Smic10;
    SFSum10(:,m) = fS10;
    fS20 = (sumSource20.*d13C_20_mean - Mic_13C*(sumSource20 - bbS) - BB_13C*bbS) / (F_13C - Mic_13C);
    micS20 = sumSource20 - bbS - fS20;
    SmicSum20F(:,m) = Smic20;
    SFSum20(:,m) = fS20;
    fS30 = (sumSource30.*d13C_30_mean - Mic_13C*(sumSource30 - bbS) - BB_13C*bbS) / (F_13C - Mic_13C);
    micS30 = sumSource30 - bbS - fS30;
    SmicSum30F(:,m) = Smic30;
    SFSum30(:,m) = fS30;
    fSraw = (sumSourceRaw.*d13C_raw_mean - Mic_13C*(sumSourceRaw - bbS) - BB_13C*bbS) / (F_13C - Mic_13C);
    micSraw = sumSourceRaw - bbS - fSraw;
    SmicSumRawF(:,m) = micSraw;
    SFSumRaw(:,m) = fSraw;

end

%Calculate mean and stdevs or monte carlo iteration
SmicRawF_mean = mean(SmicSumRawF,2);
SmicRawF_std = std(SmicSumRawF,[],2);
SFRaw_mean = mean(SFSumRaw,2);
SFRaw_std = std(SFSumRaw,[],2);
Smic10F_mean = mean(SmicSum10F,2);
Smic10F_std = std(SmicSum10F,[],2);
SF10_mean = mean(SFSum10,2);
SF10_std = std(SFSum10,[],2);
Smic20F_mean = mean(SmicSum20F,2);
Smic20F_std = std(SmicSum20F,[],2);
SF20_mean = mean(SFSum20,2);
SF20_std = std(SFSum20,[],2);
Smic30F_mean = mean(SmicSum30F,2);
Smic30F_std = std(SmicSum30F,[],2);
SF30_mean = mean(SFSum30,2);
SF30_std = std(SFSum30,[],2);


%Plot
figure (5) 
yyaxis left
a = plot (GasAgeNew,CFA_CH4);
hold on 
yyaxis right
plot (GasAgeNew(1:(end-1)),fSraw,'LineStyle','-.','color','blue','LineWidth',1,'Marker','none');
hold on 
plot (GasAgeNew(1:(end-1)),fS10,'LineStyle','--','color','blue','LineWidth',1,'Marker','none');
hold on 
b = plot (GasAgeNew(1:(end-1)),fS20,'LineStyle','-','color','blue','LineWidth',1,'Marker','none');
hold on    
plot (GasAgeNew(1:(end-1)),fS30,'LineStyle',':','color','blue','LineWidth',1,'Marker','none');
hold on 
plot (GasAgeNew(1:(end-1)),micSraw,'LineStyle','-.','color','green','LineWidth',1,'Marker','none');
hold on
plot (GasAgeNew(1:(end-1)),micS10,'LineStyle','--','color','green','LineWidth',1,'Marker','none');
hold on
c = plot (GasAgeNew(1:(end-1)),micS20,'LineStyle','-','color','green','LineWidth',1,'Marker','none');
hold on 
plot (GasAgeNew(1:(end-1)),micS30,'LineStyle',':','color','green','LineWidth',1,'Marker','none');
hold on

legend([a b c],'CFA (unsmoothed)','Thermogenic','Microbial')

%% Calculate theoretical dD for constant BB scenario 

total = Smic20F_mean + SF20_mean + bbS;
%Concentration 1 box model
CH4n = CFA_CH4(1,1)*PT;
for i = 1:length(GasAgeNew(1:(end-1)))
    CH4n = CH4n + total(i) - CH4n/(Lifetime);
    sumCH4(i,1) = CH4n/PT;
end

%1-box model for Deuterium Stable isotopes 
RD = (Smic20F_mean * Mic_D + SF20_mean * FF_D + bbS * BB_D)./(total);
dDstart2 = Ratio2D(dDstart);
nD = dDstart2*CFA_CH4(1,1)*PT;
for i = 1:length(GasAgeNew(1:(end-1)))
     nD = nD + RD(i)*total(i) - nD*(alpha_D)/(Lifetime);
     sumDn(i,1) = nD/PT;
end

%Calculate dD
dD_CH4_Cbb = ((sumDn./(sumCH4 - sumDn))/DStd - 1)*1000;

%%
f = figure (8);  %Figure 2 in main manuscript text! 
set(gca,'Color','white')
f.Position = [100 100 800 800];
hold on
set(gcf,'Color','w');
set(gca,'FontSize',15)
ax = gca;
ax.XColor = 'None';
ax.YColor = 'None';
clear ax

box on
axes('Position',[.08, .08, .35, .40])
set(gca,'Color','None')
set(gca,'FontSize',13)
ax = gca;
ax.LineWidth = 1;
set (ax,'Xdir','reverse')
yyaxis left
a = plot (GasAgeNew/1000,CFA_CH4,'LineWidth',1,'Color','b');
ylabel ('CH_4 (ppb)','FontSize',15,'Color','b')
ax.YColor = 'b';
hold on 
ylim([390 560])
yyaxis right
b = plot (GasAgeNew(1:(end-1))/1000,C13_mic_vary2,'LineWidth',1.5,'Color',"#77AC30");
hold on 
% c = plot (GasAgeNew(1:(end-1)),(C13_BB_vary),'LineWidth',1.5,'Color','red','LineStyle','-');
% hold on
ax.XColor = 'k';
ax.YColor = "#77AC30";
ylim([-65 -59])
ylabel(['{\delta}^1^3C-CH_4 (' char(8240) ,')'],'FontSize',15,'Color',"#77AC30")
xlabel('Age (kyr)','FontSize',15)
%legend([b c],'Varying Mic 13C','Varying BB 13C','FontSize',13,'location','Northwest','box','off')

box on
axes('Position',[.56, .08, .35, .40])
set(gca,'Color','None')
set(gca,'FontSize',13)
ax = gca;
ax.LineWidth = 1;
set (ax,'Xdir','reverse')
yyaxis left
a = plot (GasAgeNew/1000,CFA_CH4,'LineWidth',1,'Color','b');
%ylabel ('[CH_4] (ppb)','FontSize',13)
ax.YColor = 'b';
hold on 
ylim([390 560])
yyaxis right
b = plot (GasAgeNew(1:(end-1))/1000,C3_trop,'Color',"#7E2F8E",'LineWidth',1.5');
hold on 
c = plot (GasAgeNew(1:(end-1))/1000,C4_trop,'Color',"#D95319",'LineWidth',1.5,'LineStyle','-');
hold on
ax.XColor = 'k';
ax.YColor = 'k';
ylim([0 70])
ylabel('Emissions (Tg yr^-^1)','FontSize',15)
xlabel('Age (kyr)','FontSize',15)
legend([b c],'Tropical C3 Mic','Tropical C4 Mic','FontSize',15,'Location','northwest','box','off')

annotation('textbox',[.08 .865 .1 .1],'String','(a)','EdgeColor','none','FontSize',17,'Color','k')
annotation('textbox',[.87 .865 .1 .1],'String','(b)','EdgeColor','none','FontSize',17,'Color','k')
annotation('textbox',[.08 .38 .1 .1],'String','(c)','EdgeColor','none','FontSize',17,'Color','k')
annotation('textbox',[.87 .38 .1 .1],'String','(d)','EdgeColor','none' ,'FontSize',17,'Color','k')



%% Save data

T = table(GasAgeNew(1:(end-1)),C13Diff20Ib(1:(end-1)),Sbb20_mean,Smic20_mean,dD_CH4_Cff,fS20,micS20,dD_CH4_Cbb,Sbb20_std,Smic20_std);
filename = 'H5_1box.xlsx';
writetable(T,filename,'Sheet',1,'Range','A1')

%Save data for relative change
T2 = table(GasAgeNew(1:(end-1)),C13Diff20Ib(1:(end-1)),Sbb20_meanR,Smic20_meanR,dD_CH4_Cff,fS20,micS20,dD_CH4_Cbb,Sbb20_stdR,Smic20_stdR);
filename2 = 'H5_1boxR.xlsx';
writetable(T2,filename2,'Sheet',1,'Range','A1')

%Save mic src sig change data
T3 = table(GasAgeNew(1:(end-1)),C13_mic_vary2,C3_trop,C4_trop,CFA_CH4(1:(end-1)));
filename3 = 'H5_1box_MicVary.xlsx';
writetable(T3,filename3,'Sheet',1,'Range','A1')

 