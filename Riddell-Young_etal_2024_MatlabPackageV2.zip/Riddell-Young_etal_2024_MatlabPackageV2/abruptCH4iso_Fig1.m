%This is the code for plotting figure 1 of the abrupt CH4 isotope
%manuscript

close all 
clear all

%% Load data

%Load CFA data
CFA = xlsread('Rhodes_CFA.xlsx');   %Rhodes et al., 2015
Depth = CFA(:,1);
GasAge = CFA(:,5);
CFA_CH4 = CFA(:,4);

%Load HS1 1 box model dataset
H1_1box = xlsread('H1_1boxR.xlsx');
H1_GasAgeM = H1_1box(:,1);
H1_C13Diff20I = H1_1box(:,2);
H1_SbbSum20 = H1_1box(:,3)+1;
H1_SmicSum20 = H1_1box(:,4)+8;
H1_dD_CH4_Cff = H1_1box(:,5);
H1_fS20 = H1_1box(:,6);
H1_micS20 = H1_1box(:,7);
H1_dD_CH4_Cbb = H1_1box(:,8);
H1data = xlsread('H1_13C_Diff.xlsx');
H1_MeanDepth = H1data(1:40,1);
H1_C13Diff20 = H1data(1:40,6);
H1_C13Diff20_Unc = H1data(1:40,10);
%Interpolate age
H1_MeanAge = interp1(Depth,GasAge,H1_MeanDepth);
%Average replicates to reduce noise
%Replicates at samples 3 and 4
%Replicates at samples 11, 12, and 13
%Replicates at samples 18, 19, and 20
%Replicates at samples 29 and 30
%Replicates at samples 33 and 34
% H1MeanDepth = [H1MeanDepth(1:2);mean(H1MeanDepth(3:4));H1MeanDepth(5:10);mean(H1MeanDepth(11:13));H1MeanDepth(14:17);mean(H1MeanDepth(18:20));H1MeanDepth(21:28);mean(H1MeanDepth(29:30));H1MeanDepth(31:32);mean(H1MeanDepth(33:34));H1MeanDepth(35:40)];
% H1MeanAge = [H1MeanAge(1:2);mean(H1MeanAge(3:4));H1MeanAge(5:10);mean(H1MeanAge(11:13));H1MeanAge(14:17);mean(H1MeanAge(18:20));H1MeanAge(21:28);mean(H1MeanAge(29:30));H1MeanAge(31:32);mean(H1MeanAge(33:34));H1MeanAge(35:40)];
% H1C13Diff20 = [H1C13Diff20(1:2);mean(H1C13Diff20(3:4));H1C13Diff20(5:10);mean(H1C13Diff20(11:13));H1C13Diff20(14:17);mean(H1C13Diff20(18:20));H1C13Diff20(21:28);mean(H1C13Diff20(29:30));H1C13Diff20(31:32);mean(H1C13Diff20(33:34));H1C13Diff20(35:40)];
%Interpolate (gaussian) onto CFA age scale
H1_GasAgeNew = [15325:1:16887]';
%C13RawS = smooth(C13Raw,3);
H1_C13Diff20I = interp1(H1_MeanAge,H1_C13Diff20,H1_GasAgeNew,'pchip');

%Load HS4 1 box model dataset
H4_1box = xlsread('H4_1boxR.xlsx');
H4_GasAgeM = H4_1box(:,1);
H4_C13Diff20I = H4_1box(:,2);
H4_SbbSum20 = H4_1box(:,3)+3;
H4_SmicSum20 = H4_1box(:,4)+12;
H4_dD_CH4_Cff = H4_1box(:,5);
%dD_CH4_Cff = smooth(GasAgeM,dD_CH4_Cff,.01,'rloess');
H4_fS20 = H4_1box(:,6);
H4_micS20 = H4_1box(:,7);
H4_dD_CH4_Cbb = H4_1box(:,8);
%dD_CH4_Cbb = smooth(GasAgeM,dD_CH4_Cbb,.01,'rloess');
%Load H4 C13 data
H4_data = xlsread('H4_13C_Diff.xlsx');
H4_MeanDepth = H4_data(:,1) - 0.7375;          %subtract 0.7375m from depth because of replicate core offset (T.J. Fudge, personal comm)
H4_C13Diff20 = H4_data(:,6);
H4_C13Diff20_Unc = H4_data(:,11);
%Interpolate age
H4_MeanAge = interp1(Depth,GasAge,H4_MeanDepth);
%Load H4 dD
H4_dDdata = xlsread('H4_dD_Diff.xlsx');
H4_dDMeanDepth = H4_dDdata(:,1) - 0.7375;          %Add 0.7375m to depth because of replicate core offset (T.J. Fudge, personal comm)
H4_dDDiff20 = H4_dDdata(:,5);
%Interpolate age
H4_dDMeanAge = interp1(Depth,GasAge,H4_dDMeanDepth);
%Interpolate (gaussian) onto CFA age scale
H4_dDGasAgeNew = [39160:1:39733]';
H4_dDDiff20I = interp1(H4_dDMeanAge,H4_dDDiff20,H4_dDGasAgeNew,'pchip');

%Load HS5 1 box model dataset
H5_1box = xlsread('H5_1boxR.xlsx');
H5_GasAgeM = H5_1box(:,1);
H5_C13Diff20I = H5_1box(:,2);
H5_SbbSum20 = H5_1box(:,3)+2;
H5_SmicSum20 = H5_1box(:,4)+11;
H5_dD_CH4_Cff = H5_1box(:,5);
H5_dD_CH4_Cff = smooth(H5_GasAgeM,H5_dD_CH4_Cff,.01,'rloess');
H5_fS20 = H5_1box(:,6);
H5_micS20 = H5_1box(:,7);
H5_dD_CH4_Cbb = H5_1box(:,8);
H5_dD_CH4_Cbb = smooth(H5_GasAgeM,H5_dD_CH4_Cbb,.01,'rloess');
%Load H5 C13 data
H5_data = xlsread('H5_13C_Diff.xlsx');
H5_MeanDepth = H5_data(:,1);          
H5_C13Diff20 = H5_data(:,6);
H5_C13Diff20_Unc = H5_data(:,10);
%Interpolate age
H5_MeanAge = interp1(Depth,GasAge,H5_MeanDepth);
%Average points 17 and 18
H5_MeanAge = [H5_MeanAge(1:25);mean(H5_MeanAge(26:27));H5_MeanAge(28:43)];
H5_C13Diff20 = [H5_C13Diff20(1:25);mean(H5_C13Diff20(26:27));H5_C13Diff20(28:43)];
H5_C13Diff20_Unc = [H5_C13Diff20_Unc(1:25);mean(H5_C13Diff20_Unc(26:27));H5_C13Diff20_Unc(28:43)];

%% Load other isotope data
%13C data first
%Load Bock 2017 13C (age scale adusted 350 years to match data)
BockTaldice_data = xlsread('Bock2017_Taldice_C13.xlsx');
TAge = BockTaldice_data(:,2)*1000;
T13C = BockTaldice_data(:,11);
BockEDC_data = xlsread('EDC_13C.xlsx');
EDCAge = BockEDC_data(:,2);
EDC13C = BockEDC_data(:,7);
%Load Moller 2013
EDML_data = xlsread('EDML_13C.xlsx');
EDMLAge = EDML_data(:,2);
EDML13C = EDML_data(:,7);
%Now dD data 
%Load Bock 2010
NGRIP_data = xlsread('Bock_NGRIP_dD.xlsx');
NGRIPAge = NGRIP_data(:,3);
NGRIPdD = NGRIP_data(:,6);
%Load Bock 2017
dDEDML_data = xlsread('Bock_EDML_dD_2017.xlsx');
dDEDMLAge = dDEDML_data(:,2)*1000;
dDEDML = dDEDML_data(:,6);
%Load Sowers 2006
Sowers_dD = xlsread('Sowers_2006_dD.xlsx');
SowersAge = Sowers_dD(:,2)*1000;
SowersdD = Sowers_dD(:,3);

%% Load data for other proxies

%H1 other data
H1_SpelN = csvread('Zhang_2014_HuluH1.csv',1,0);
H1_SpelNb = csvread('Wang2001_Hulu_H1.csv',1,0);
H1_SpelS = csvread('strikis2018_H1_SAM.csv',1,0);
CO2data = csvread('Bauska_CO2.csv',1,0);
NGRIP_O18data = csvread('NGRIP_18O.csv',1,0);

%H4 other data
H4_SpelN = csvread('Cheng_2016.csv',1,0);
H4_SpelS = csvread('H4_brazil_wendt.csv',1,0);     %Only for Heinrich 4
%Load Jons rIPD data
H4_GISP2rIPD = csvread('DO8HS4rIPDforBen.csv',1,0);
%Create artificial greenland CH4 record
H4_interpWDCCH4 = interp1(GasAge,CFA_CH4,H4_GISP2rIPD(:,1));
H4_GreenlandCH4 = H4_interpWDCCH4.*(1+H4_GISP2rIPD(:,4)/100);

%H5 other data
H5_SpelN = csvread('Cheng_2016.csv',1,0);
%SpelS = csvread('H4_brazil_wendt.csv',1,0);     %Only for Heinrich 4

%% What is the total biomass burning perturbation?

%For H4, integrate from 954 to 1064
H4start = H4_SbbSum20(954);
H4end = H4_SbbSum20(1064);
H4dif = H4end - H4start;
H4IntDif = H4dif*(1064 - 954)/2;
%For H5, integrate from 1262 to 1512
H5start = H5_SbbSum20(1262);
H5end = H5_SbbSum20(1512);
H5dif = H5end - H5start;
H5IntDif = H5dif*(1512 - 1262)/2;
%For H1, integrate from 738 to 918
H1start = H1_SbbSum20(738);
H1end = H1_SbbSum20(918);
H1dif = H1start - H1end;
H1IntDif = H1dif*(918 - 738)/2;

%integrate
H5 = trapz(H5_SbbSum20(1262:1512)-H5start) - H5IntDif;
H5rate = H5/(1512 - 1262);
    %2 sigma uncertainty
    H5UncM = mean(H5_1box(1262:1512,9));
    H5uncT = H5UncM*(1512-1262);

H4 = trapz(H4_SbbSum20(954:1064)-H4start) - H4IntDif;
H4rate = H4/(1064 - 954);
    %2 sigma uncertainty
    H4UncM = mean(H4_1box(954:1064,9));
    H4uncT = H4UncM*(1064-954);

H1 = trapz(H1_SbbSum20(738:918)-H1start) - H1IntDif;
H1rate = H1/(918 - 738);
    %2 sigma uncertainty
    H1UncM = mean(H1_1box(738:918,9));
    H1uncT = H1UncM*(918-738);

%Check plot
figure (5)
plot(H5_SbbSum20(1262:1512)-H5start)
hold on
line([0,(1512-1262)],[(H5_SbbSum20(1262)-H5start),(H5_SbbSum20(1512)-H5start)])

%% Plot

f = figure(1);
f.Position = [100 100 900 800];
hold on
set(gcf,'Color','w');
ax = gca;
ax.XColor = 'None';
ax.YColor = 'None';
clear ax

%% First plot H5

%CFA CH4 record
box off
axes('Position',[.08, .75, .25, .19])
set(gca,'Color','None')
ax = gca;
set (ax,'Xdir','reverse')
hold on
plot (GasAge,CFA_CH4,'LineWidth',2,'Color','b');
hold on
xlim([46500 49800])
ylim([375 630])
ax.XColor = 'None';
ax.YColor = 'k';
ylabel('CH_4 (ppb)','FontSize',15)
set(gca,'FontSize',15)

%13C-CH4 data
box off
axes('Position',[.08, .57, .25, .23])
set(gca,'Color','None')
ax = gca;
set (ax,'Xdir','reverse')
yyaxis right
hold on
a = plot (TAge,T13C,'LineStyle','-','Color',"#77AC30",'Marker','o','MarkerEdgeColor',"#77AC30",'LineWidth',.75,'MarkerSize',1);
hold on 
aa = errorbar(TAge,T13C,.15,'CapSize',.5,'Marker','none','LineStyle','none','Color',"#77AC30");
hold on
% scatter (EDCAge,EDC13C,'blue')
% hold on
b = plot (EDMLAge,EDML13C,'LineStyle','-','Color',"#EDB120",'Marker','o','MarkerEdgeColor',"#EDB120",'LineWidth',.75,'MarkerSize',1);
hold on 
bb = errorbar(EDMLAge,EDML13C,.15,'CapSize',.5,'Marker','none','LineStyle','none','Color',"#EDB120");
hold on
plot (H5_GasAgeM,H5_C13Diff20I,'LineWidth',1,'Color','k','LineStyle','-','Marker','none');
hold on
c = plot (H5_MeanAge,H5_C13Diff20,'Marker','d','LineStyle','none','MarkerSize',1,'MarkerFaceColor',"#A2142F",'MarkerEdgeColor',"#A2142F");
hold on
cc = errorbar(H5_MeanAge,H5_C13Diff20,H5_C13Diff20_Unc,'CapSize',.5,'Marker','none','LineStyle','none','Color',"#A2142F");
hold on
xlim([46500 49800])
ylim([-47.7 -42])
ax.XColor = 'None';
ax.YColor = 'k';
set(gca,'YTickLabel', [])
%legend([a b c],'Bock 2017','Möller 2013','This Study','Location','best','FontSize',12,'EdgeColor','none','Color','none')
%ylabel(['\delta^1^3C-CH_4 ( ',char(8240),')'],'FontSize',15)
set(gca,'FontSize',15)
yyaxis left
ax.YColor = 'None';

%BB
box off
axes('Position',[.08, .41, .25, .22])
set(gca,'Color','None')
ax = gca;
set (ax,'Xdir','reverse')
hold on
a = plot (H5_GasAgeM,(H5_SbbSum20),'LineStyle','-','LineWidth',2,'Color',"#A2142F");%./(SbbSum20+SmicSum20+30)))
hold on
jbfill(H5_GasAgeM',(H5_SbbSum20 + 2*H5_1box(:,9))',(H5_SbbSum20 - 2*H5_1box(:,9))',[0.6350 0.0780 0.1840],'none');
hold on
%b = plot (GasAgeM,(fS20),'LineStyle','-','LineWidth',2,'Color',"#0072BD");%./(fS20+micS20+20)))
%hold on
xlim([46500 49800])
ylim([-3 14])
ax.XColor = 'None';
ax.YColor = 'k';
ylabel('\Delta Pyro (Tg yr^-^1)','FontSize',15)
set(gca,'FontSize',15)
%legend([a b],'BB','Geo','Location','west','FontSize',12,'EdgeColor','none','Color','none')

%Mic
box off
axes('Position',[.08, .28, .25, .18])
set(gca,'Color','None')
ax = gca;
set (ax,'Xdir','reverse')
hold on
yyaxis right
a = plot (H5_GasAgeM,(H5_SmicSum20),'LineStyle','-','LineWidth',2,'Color',"#77AC30");%./(SbbSum20+SmicSum20+30)))
hold on
jbfill(H5_GasAgeM',(H5_SmicSum20 + 2*H5_1box(:,10))',(H5_SmicSum20 - 2*H5_1box(:,10))',[0.4660 0.6740 0.1880],'none');
hold on
%b = plot (GasAgeM,(micS20),'LineStyle','-.','LineWidth',2,'Color',"#77AC30");%./(fS20+micS20+20)))
%hold on
xlim([46500 49800])
ylim([-7 43])
ax.XColor = 'None';
ax.YColor = 'k';
%ylabel('Mic (Tg yr^-^1)','FontSize',15)
set(gca,'FontSize',15)
set(gca,'YTickLabel', [])
%legend([a b],'Mic (const. Geo)','Mic (const. BB)','Location','west','FontSize',12,'EdgeColor','none','Color','none')
yyaxis left
ax.YColor = 'None';

%Speleothem data
box off
axes('Position',[.08, .11, .25, .16])
set(gca,'Color','None')
ax = gca;
set (ax,'Xdir','reverse')
set (ax,'Ydir','reverse')
hold on
yyaxis left
plot (H5_SpelN(:,1),H5_SpelN(:,2),'LineWidth',1.5,'Color',[.64 .35 .29])
hold on
ax.YColor = '[.64 .35 .29]';
ylabel(['\delta^1^8O_{ASM} ( ',char(8240),')'],'FontSize',15,'Color',[.64 .35 .29])
set(gca,'FontSize',15)
ylim([-11 -4])
yyaxis right
set (ax,'Xdir','reverse')
set (ax,'Ydir','reverse')
%plot (SpelS(:,1),SpelS(:,3),'LineWidth',1.5,'Color',[.37 .55 .24])
hold on
xlim([46.5 49.8])
ylim([-9 -1])
yticks([-8 -6 -4 -2])
ax.XColor = 'k';
ax.YColor = [.37 .55 .24];
xlabel('Age (Kyr BP)','FontSize',15)
%ylabel(['\delta^1^8O_{SAM} ( ',char(8240),')'],'FontSize',15,'Color',[.37 .55 .24])
set(gca,'FontSize',15)
set(gca,'YTickLabel', [])


%% Next plot H4
%CFA CH4 record
box off
axes('Position',[.37, .75, .25, .19])
set(gca,'Color','None')
ax = gca;
set (ax,'Xdir','reverse')
hold on
plot (GasAge,CFA_CH4,'LineWidth',2,'Color','b');
hold on
xlim([37500 40800])
ylim([375 630])
ax.XColor = 'None';
ax.YColor = 'k';
%ylabel('[CH_4] (ppb)','FontSize',15)
set(gca,'FontSize',15)
set(gca,'YTickLabel', [])

%13C-CH4 data
box off
axes('Position',[.37, .57, .25, .23])
set(gca,'Color','None')
ax = gca;
set (ax,'Xdir','reverse')
yyaxis right
hold on
a = plot (TAge,T13C,'LineStyle','-','Color',"#77AC30",'Marker','o','MarkerEdgeColor',"#77AC30",'LineWidth',.75,'MarkerSize',1);
hold on 
cc = errorbar(TAge,T13C,0.15,'CapSize',.5,'Marker','none','LineStyle','none','Color',"#77AC30");
hold on
% scatter (EDCAge,EDC13C,'blue')
% hold on
b = plot (EDMLAge,EDML13C,'LineStyle','-','Color',"#EDB120",'Marker','o','MarkerEdgeColor',"#EDB120",'LineWidth',.75,'MarkerSize',1);
hold on 
bb = errorbar(EDMLAge,EDML13C,0.15,'CapSize',.5,'Marker','none','LineStyle','none','Color',"#EDB120");
hold on
plot (H4_GasAgeM,H4_C13Diff20I,'LineWidth',1,'Color','k','LineStyle','-','Marker','none');
hold on
c = plot (H4_MeanAge,H4_C13Diff20,'Marker','d','LineStyle','none','MarkerSize',1,'MarkerFaceColor',"#A2142F",'MarkerEdgeColor',"#A2142F");
hold on
cc = errorbar(H4_MeanAge,H4_C13Diff20,H4_C13Diff20_Unc,'CapSize',.5,'Marker','none','LineStyle','none','Color',"#A2142F");
hold on
xlim([37500 40800])
ylim([-47.7 -42])
ax.XColor = 'None';
ax.YColor = 'k';
% legend([a b c],'Bock 2017','Möller 2013','This Study','Location','best','FontSize',12,'EdgeColor','none','Color','none')
%ylabel(['\delta^1^3C-CH_4 ( ',char(8240),')'],'FontSize',15)
set(gca,'FontSize',15)
set(gca,'YTickLabel', [])
yyaxis left
ax.YColor = 'None';
set(gca,'YTickLabel', [])

%Pyrogenic
box off
axes('Position',[.37, .41, .25, .22])
set(gca,'Color','None')
ax = gca;
set (ax,'Xdir','reverse')
hold on
a = plot (H4_GasAgeM,(H4_SbbSum20),'LineStyle','-','LineWidth',2,'Color',"#A2142F");%./(SbbSum20+SmicSum20+30)))
hold on
jbfill(H4_GasAgeM',(H4_SbbSum20 + 2*H4_1box(:,9))',(H4_SbbSum20 - 2*H4_1box(:,9))',[0.6350 0.0780 0.1840],'none');
hold on
%b = plot (GasAgeM,(fS20),'LineStyle','-','LineWidth',2,'Color',"#0072BD");%./(fS20+micS20+20)))
%hold on
xlim([37500 40800])
ylim([-3 14])
ax.XColor = 'None';
ax.YColor = 'k';
%ylabel('BB (Tg yr^-^1)','FontSize',15)
set(gca,'FontSize',15)
set(gca,'YTickLabel', [])
%legend([a b],'BB','Geo','Location','west','FontSize',12,'EdgeColor','none','Color','none')

%Mic
box off
axes('Position',[.37, .28, .25, .18])
set(gca,'Color','None')
ax = gca;
set (ax,'Xdir','reverse')
hold on
yyaxis right
a = plot (H4_GasAgeM,(H4_SmicSum20),'LineStyle','-','LineWidth',2,'Color',"#77AC30");%./(SbbSum20+SmicSum20+30)))
hold on
jbfill(H4_GasAgeM',(H4_SmicSum20 + 2*H4_1box(:,10))',(H4_SmicSum20 - 2*H4_1box(:,10))',[0.4660 0.6740 0.1880],'none');
hold on
%b = plot (GasAgeM,(micS20),'LineStyle','-.','LineWidth',2,'Color',"#77AC30");%./(fS20+micS20+20)))
%hold on
xlim([37500 40800])
ylim([-7 43])
ax.XColor = 'None';
ax.YColor = 'k';
%ylabel('Mic (Tg yr^-^1)','FontSize',15)
set(gca,'FontSize',15)
set(gca,'YTickLabel', [])
%legend([a b],'Mic (const. Geo)','Mic (const. BB)','Location','west','FontSize',12,'EdgeColor','none','Color','none')
yyaxis left
ax.YColor = 'None';
set(gca,'YTickLabel', [])

%Northern and southern speleothem data
box off
axes('Position',[.37, .11, .25, .16])
set(gca,'Color','None')
ax = gca;
set (ax,'Xdir','reverse')
set (ax,'Ydir','reverse')
hold on
yyaxis left
plot (H4_SpelN(:,1),H4_SpelN(:,2),'LineWidth',1.5,'Color',[.64 .35 .29])
hold on
ax.YColor = '[.64 .35 .29]';
%ylabel(['\delta^1^8O_{Hulu} ( ',char(8240),')'],'FontSize',15,'Color',[.64 .35 .29])
set(gca,'FontSize',15)
ylim([-11 -4])
set(gca,'YTickLabel', [])
yyaxis right
set (ax,'Xdir','reverse')
set (ax,'Ydir','reverse')
plot (H4_SpelS(:,1)/1000,H4_SpelS(:,3),'LineWidth',1.5,'Color',[.37 .55 .24])
hold on
xlim([37.5 40.8])
ylim([-9 -1])
yticks([-8 -6 -4 -2])
ax.XColor = 'k';
ax.YColor = '[.37 .55 .24]';
%ylabel(['\delta^1^8O_{SAM} ( ',char(8240),')'],'FontSize',15,'Color',[.37 .55 .24])
xlabel('Age (Kyr BP)','FontSize',15)
set(gca,'FontSize',15)
set(gca,'YTickLabel', [])


%% Lastly plot H1
%CFA CH4 record
box off
axes('Position',[.66, .75, .25, .19])
set(gca,'Color','None')
ax = gca;
set (ax,'Xdir','reverse')
hold on
plot (GasAge,CFA_CH4,'LineWidth',2,'Color','b');
hold on
xlim([14200 17100])
ylim([375 630])
%legend('Rhodes 2015','Location','Northwest','FontSize',12,'EdgeColor','none','Color','none')
ax.XColor = 'None';
ax.YColor = 'k';
%ylabel('[CH_4] (ppb)','FontSize',15)
set(gca,'FontSize',15)
set(gca,'YTickLabel', [])

%13C-CH4 data
box off
axes('Position',[.66, .56, .25, .23])
set(gca,'Color','None')
ax = gca;
set (ax,'Xdir','reverse')
hold on
yyaxis right
a = plot (TAge,T13C,'LineStyle','-','Color',"#77AC30",'Marker','o','MarkerEdgeColor',"#77AC30",'LineWidth',.75,'MarkerSize',1);
hold on
bb = errorbar(TAge,T13C,0.15,'CapSize',.5,'Marker','none','LineStyle','none','Color',"#77AC30");
hold on
scatter (EDCAge,EDC13C,'blue')
hold on
b = plot (EDMLAge,EDML13C,'LineStyle','-','Color',"#EDB120",'Marker','o','MarkerEdgeColor',"#EDB120",'LineWidth',.75,'MarkerSize',1);
hold on 
bb = errorbar(EDMLAge,EDML13C,0.15,'CapSize',.5,'Marker','none','LineStyle','none','Color',"#EDB120");
hold on
plot (H1_GasAgeNew,H1_C13Diff20I,'LineWidth',1,'Color','k','LineStyle','-','Marker','none');
hold on
c = plot (H1_MeanAge,H1_C13Diff20,'Marker','d','LineStyle','none','MarkerSize',1,'MarkerFaceColor',"#A2142F",'MarkerEdgeColor',"#A2142F",'LineWidth',1,'Color','k','LineStyle','-');
hold on
cc = errorbar(H1_MeanAge,H1_C13Diff20,H1_C13Diff20_Unc,'CapSize',.5,'Marker','none','LineStyle','none','Color',"#A2142F");
hold on
xlim([14200 17100])
ylim([-47.7 -42])
leg = legend([a b c],'Bock 2017','Möller 2013','This Study','Location','east','FontSize',12,'EdgeColor','none','Color','none');
leg.ItemTokenSize(1) = 12;
ax.XColor = 'None';
ax.YColor = 'k';
ylabel(['\delta^1^3C-CH_4 ( ',char(8240),')'],'FontSize',15)
set(gca,'FontSize',15)
yyaxis left
ax.YColor = 'None';

%Fraction BB for constant FF 
box off
axes('Position',[.66, .41, .25, .22])
set(gca,'Color','None')
ax = gca;
set (ax,'Xdir','reverse')
hold on
a = plot (H1_GasAgeM,(H1_SbbSum20),'LineStyle','-','LineWidth',2,'Color',"#A2142F");%./(SbbSum20+SmicSum20+30)))
hold on
jbfill(H1_GasAgeM',(H1_SbbSum20 + 2*H1_1box(:,9))',(H1_SbbSum20 - 2*H1_1box(:,9))',[0.6350 0.0780 0.1840],'none');
hold on
% c = plot (GasAgeM,(fS20),'LineStyle','-','LineWidth',1.5,'Color',"#0072BD");%./(fS20+micS20+20)))
% hold on
% d = plot (GasAgeM,(micS20),'LineStyle','-.','LineWidth',1.5,'Color',"#77AC30");%./(fS20+micS20+20)))
% hold on
xlim([14200 17100])
ax.XColor = 'None';
ax.YColor = 'k';
ylim([-3 14])
%ylabel('BB (Tg yr^-^1)','FontSize',15)
set(gca,'FontSize',15)
set(gca,'YTickLabel', [])
%legend([a b c d],'BB','Mic (const. Geo.)','Geologic','Mic (const. BB)','Location','east','FontSize',12,'EdgeColor','none','Color','none')

%Fraction Mic for constant FF 
box off
axes('Position',[.66, .28, .25, .18])
set(gca,'Color','None')
ax = gca;
set (ax,'Xdir','reverse')
hold on
yyaxis right
b = plot (H1_GasAgeM,(H1_SmicSum20),'LineStyle','-','LineWidth',2,'Color',"#77AC30");%./(SbbSum20+SmicSum20+30)))
hold on
jbfill(H1_GasAgeM',(H1_SmicSum20 + 2*H1_1box(:,10))',(H1_SmicSum20 - 2*H1_1box(:,10))',[0.4660 0.6740 0.1880],'none');
hold on
% c = plot (GasAgeM,(fS20),'LineStyle','-','LineWidth',1.5,'Color',"#0072BD");%./(fS20+micS20+20)))
% hold on
% d = plot (GasAgeM,(micS20),'LineStyle','-.','LineWidth',1.5,'Color',"#77AC30");%./(fS20+micS20+20)))
% hold on
xlim([14200 17100])
ylim([-7 43])
ax.XColor = 'None';
ax.YColor = 'k';
%xlabel('Age (KaBP)','FontSize',15)
ylabel('\Delta Mic (Tg yr^-^1)','FontSize',15)
set(gca,'FontSize',15)
%legend([a b c d],'BB','Mic (const. Geo.)','Geologic','Mic (const. BB)','Location','east','FontSize',12,'EdgeColor','none','Color','none')
yyaxis left
ax.YColor = 'None';

%plot speleothem data
box off
axes('Position',[.66, .11, .25, .16])
set(gca,'Color','None')
ax = gca;
set (ax,'Xdir','reverse')
set (ax,'Ydir','reverse')
hold on
yyaxis left
a = plot (H1_SpelN(:,2)/1000,H1_SpelN(:,3),'LineWidth',1.5,'Color',[.64 .35 .29])
hold on
ylim([-11 -4])
ax.YColor = '[.64 .35 .29]';
%ylabel(['\delta^1^8O_{Hulu} ( ',char(8240),')'],'FontSize',15,'Color',[.64 .35 .29])
set(gca,'FontSize',15)
set(gca,'YTickLabel', [])
yyaxis right
set (ax,'Xdir','reverse')
set (ax,'Ydir','reverse')
b = plot (H1_SpelS(1:800,2),H1_SpelS(1:800,3),'LineWidth',1.5,'Color',[.37 .55 .24])
hold on
xlim([14 17.1])
ylim([-9 -1])
yticks([-8 -6 -4 -2])
ax.XColor = 'k';
ax.YColor = '[.37 .55 .24]';
ylabel(['\delta^1^8O_{SAM} ( ',char(8240),')'],'FontSize',15,'Color',[.37 .55 .24])
lega = legend([a b],'ASM','SAM','This Study','Location','east','FontSize',12,'EdgeColor','none','Color','none');
lega.ItemTokenSize(1) = 12;
xlabel('Age (Kyr BP)','FontSize',15)
set(gca,'FontSize',15)


%% Add labels and shading

%H5 labels
annotation('textbox',[.09 .77 .1 .1],'String','DO 13','EdgeColor','none','FontSize',14,'FontWeight','bold','Color','k')
annotation('textbox',[.28 .81 .1 .1],'String','DO 12','EdgeColor','none','FontSize',14,'FontWeight','bold','Color','k')

%H4 labels
annotation('textbox',[.385 .76 .1 .1],'String','DO 9','EdgeColor','none','FontSize',14,'FontWeight','bold','Color','k')
%annotation('textbox',[.44 .76 .1 .1],'String','DO 9','EdgeColor','none','FontSize',14,'FontWeight','bold','Color','k')
annotation('textbox',[.56 .84 .1 .1],'String','DO 8','EdgeColor','none','FontSize',14,'FontWeight','bold','Color','k')

%H1 labels
annotation('textbox',[.885 .81 .1 .1],'String','BA','EdgeColor','none','FontSize',13,'FontWeight','bold','Color','k')

%Label boxes 
annotation('textbox',[.0775 .85 .1 .1],'String','(a)','EdgeColor','none','FontSize',17,'Color',[.3 .3 .3])
annotation('textbox',[.875 .69 .1 .1],'String','(b)','EdgeColor','none','FontSize',17,'Color',[.3 .3 .3])
annotation('textbox',[.0775 .5 .1 .1],'String','(c)','EdgeColor','none','FontSize',17,'Color',[.3 .3 .3])
annotation('textbox',[.875 .37 .1 .1],'String','(d)','EdgeColor','none' ,'FontSize',17,'Color',[.3 .3 .3])
annotation('textbox',[.075 .185 .1 .1],'String','(e)','EdgeColor','none','FontSize',17,'Color',[.3 .3 .3])

%Label columns
annotation('textbox',[.165 .88 .1 .1],'String','HE5','EdgeColor','none','FontSize',18,'FontWeight','bold','Color','k')
annotation('textbox',[.44 .88 .1 .1],'String','HE4','EdgeColor','none','FontSize',18,'FontWeight','bold','Color','k')
annotation('textbox',[.715 .88 .1 .1],'String','HE1','EdgeColor','none','FontSize',18,'FontWeight','bold','Color','k')

%Shade heinrich intervals
%H5 shading
%annotation('rectangle',[.15 .11 .1325 .83],'FaceColor','k','FaceAlpha',.1,'EdgeColor','none')
annotation('line',[.19 .19],[.11 .94],'Color','k','LineStyle','--');
%H4 shading
%annotation('rectangle',[.4225 .11 .125 .83],'FaceColor','k','FaceAlpha',.1,'EdgeColor','none')
annotation('line',[.465 .465],[.11 .94],'Color','k','LineStyle','--');
%H1 shading
%annotation('rectangle',[.66 .11 .21 .83],'FaceColor','k','FaceAlpha',.1,'EdgeColor','none')
annotation('line',[.7425 .7425],[.11 .94],'Color','k','LineStyle','--');

