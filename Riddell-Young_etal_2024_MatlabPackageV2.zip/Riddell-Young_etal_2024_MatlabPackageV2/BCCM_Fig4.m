% Code for figure 4 of the abrupt CH4 isotope manuscript

% This code displays the carbon cycle box model output for HS5, 4, and 1 
% for both CO2 mixing ratio and stable isotopes vs data. The model output
% from bauska et al., 2021 is also included

close all 
clear all

%Load data
%Methane data
CFA = xlsread('Rhodes_CFA.xlsx');   %Rhodes et al., 2015
Depth = CFA(:,1);
GasAge = CFA(:,5);
CFA_CH4 = CFA(:,4);

%CO2 data (Marcott et al., 2014, Bauska et al., 2021)
CO2data = xlsread('WD06_CO2.xlsx');
CO2age = CO2data(:,2);
CO2 = CO2data(:,3);

%d13C-CO2 data (Bauska et al., 2016; 2018)
C13CO2data = csvread('Bauska2018_d13C-CO2.csv',1,0);
d13Cage = C13CO2data(:,1);
d13C = C13CO2data(:,3);

%carbon cyle model output data
CCM = csvread('BCCM_July2024.csv',1,0);
%Original Bauska et al., 2021 model
Age = -1*CCM(:,1);
mCO2_mean = CCM(:,2);
mCO2_min = CCM(:,3);
mCO2_max = CCM(:,4);
m13C_mean = CCM(:,5);
m13C_min = CCM(:,6);
m13C_max = CCM(:,7);
%Model with pyrogenic emissions
pCO2_min = CCM(:,8);
pCO2_max = CCM(:,9);
p13C_min = CCM(:,10);
p13C_max = CCM(:,11);
%Model with NPP change (wetlands) 
wCO2 = CCM(:,12);
wd13C = CCM(:,13);


%% Histogram calculations from Thomas Bauska

Diff_matrix = xlsread('Diff_matrix.xlsx');
H5diff = xlsread('H5diff.xlsx');
H4diff = xlsread('H4diff.xlsx'); 
H1diff = xlsread('H1diff.xlsx');
H5diff_data = Diff_matrix(1,1);
H4diff_data = Diff_matrix(2,1);
H1diff_data = Diff_matrix(3,1);
H5diff_baseline = Diff_matrix(1,2);
H4diff_baseline = Diff_matrix(2,2);
H1diff_baseline = Diff_matrix(3,2);


%% Plot data! 

close all 

f = figure(1);
f.Position = [100 100 900 850];
hold on
set(gcf,'Color','w');
ax = gca;
ax.XColor = 'None';
ax.YColor = 'None';
clear ax

% First plot H5
%CFA CH4 record
box off
axes('Position',[.08, .77, .27, .18])
set(gca,'Color','None')
ax = gca;
set (ax,'Xdir','reverse')
set (ax,'LineWidth',1)
hold on
plot (GasAge/1000,CFA_CH4,'LineWidth',1.5,'Color','b');
hold on
xlim([47500/1000 49000/1000])
ylim([395 480])
ax.XColor = 'None';
ax.YColor = 'k';
ylabel('CH_4 (ppb)','FontSize',15)
set(gca,'FontSize',15)

%Modeled and ice core CO2 data
box off
axes('Position',[.08, .55, .27, .2])
set(gca,'Color','None')
ax = gca;
set (ax,'Xdir','reverse')
set (ax,'LineWidth',1)
hold on
%Plot pyrogenic model and unceratinty
plot (Age/1000,pCO2_min-242,'LineStyle','-','Color',[0.8500 0.3250 0.0980],'LineWidth',.75);
hold on
plot (Age/1000,pCO2_max-242,'LineStyle','-','Color',[0.8500 0.3250 0.0980],'LineWidth',.75);
hold on
c = jbfill(Age'/1000,(pCO2_min-242)',(pCO2_max-242)',[0.9290 0.6940 0.1250],'none');
hold on
%Plot CO2 data
a = plot (CO2age/1000,CO2-202,'LineStyle','-','Color','k','Marker','.','MarkerEdgeColor','k','LineWidth',.75,'MarkerSize',10);
hold on
aa = errorbar(CO2age/1000,CO2-202,0.7,'CapSize',.2,'Marker','none','LineStyle','none','Color','k');
hold on
% Plot Bauska 2021 model ouput
b = plot (Age/1000,mCO2_mean-243,'LineStyle','-','Color',[0.6350 0.0780 0.1840],'LineWidth',2);
hold on
xlim([47500/1000 49000/1000])
ylim([-5 36])
ax.XColor = 'none';
ax.YColor = 'k';
xlabel('Age (kyr BP)','FontSize',15)
set(gca,'FontSize',15)
ylabel('\Delta CO_2 (ppm)','FontSize',15)
%legend([a b c],'Data','Model CO_2 w/out Pyro','Model CO_2 w/Pyro','Location','northeast','FontSize',12,'EdgeColor','none','Color','none')


%modeled and ice core d13C-CO2 data
box off
axes('Position',[.08, .33, .27, .2])
set(gca,'Color','None')
ax = gca;
set (ax,'Xdir','reverse')
set (ax,'LineWidth',1)
hold on
% Plot pyrogenic model and unceratinty
plot (Age/1000,p13C_min+6.4,'LineStyle','-','Color',[0.8500 0.3250 0.0980],'LineWidth',.75);
hold on
plot (Age/1000,p13C_max+6.4,'LineStyle','-','Color',[0.8500 0.3250 0.0980],'LineWidth',.75);
hold on
cc = jbfill(Age'/1000,(p13C_min+6.4)',(p13C_max+6.4)',[0.9290 0.6940 0.1250],'none');
hold on
% Plot CO2 data
aa = plot ((d13Cage-230)/1000,d13C+6.5,'LineStyle','-','Color','k','Marker','.','MarkerEdgeColor','k','LineWidth',1,'MarkerSize',10);
hold on
aaa = errorbar((d13Cage-230)/1000,d13C+6.5,0.02,'CapSize',.2,'Marker','none','LineStyle','none','Color','k');
hold on
% Plot Bauska 2021 model ouput
bb = plot (Age/1000,m13C_mean+6.42,'LineStyle','-','Color',[0.6350 0.0780 0.1840],'LineWidth',2);
hold on
xlim([47500/1000 49000/1000])
ylim([-0.5 0.15])
ax.XColor = 'k';
ax.YColor = 'k';
ylabel(['\Delta \delta^1^3C-CO_2 ( ',char(8240),')'],'FontSize',15)
xlabel('Age (kyr BP)','FontSize',15)
set(gca,'FontSize',15)
%legend([aa bb cc],'WDC \delta^1^3CO_2','Model \delta^1^3CO_2 w/out Pyro','Model \delta^1^3CO_2 w/Pyro','Location','southwest','FontSize',12,'EdgeColor','none','Color','none')
legend([aa bb cc],'Ice Core Data','Baseline (No Fire)','Baseline + Fire','Location','southwest','FontSize',12,'EdgeColor','none','Color','none')

%Plot histogram
box off
axes('Position',[.08, .065, .27, .2])
set(gca,'Color','None')
ax = gca;
set (ax,'LineWidth',1)
hold on
histogram(H5diff_data, 'BinWidth', 1,'Normalization','probability','FaceColor','k') 
histogram(H5diff, 'BinWidth', 1,'Normalization','probability','FaceColor',[0.9290 0.6940 0.1250]) 
histogram(H5diff_baseline, 'BinWidth', 1,'Normalization','probability','FaceColor',[0.6350 0.0780 0.1840]) 
xlabel('HE5 \Delta CO_2 (ppm)','FontSize',15)
ylabel('Probability','FontSize',15)
ax.XColor = 'k';
ax.YColor = 'k';
xlim([0 30])
ylim([0 0.2])
set(gca,'FontSize',15)



% Next plot H4
%CFA CH4 record
box off
axes('Position',[.39, .77, .27, .18])
set(gca,'Color','None')
ax = gca;
set (ax,'Xdir','reverse')
set (ax,'LineWidth',1)
hold on
plot (GasAge/1000,CFA_CH4,'LineWidth',1.5,'Color','b');
hold on
xlim([38500/1000 40000/1000])
ylim([395 480])
ax.XColor = 'None';
ax.YColor = 'k';
%ylabel('[CH_4] (ppb)','FontSize',15)
set(gca,'FontSize',15)
set(gca,'YTickLabel', [])

%Modeled and ice core CO2 data
box off
axes('Position',[.39, .55, .27, .2])
set(gca,'Color','None')
ax = gca;
set (ax,'Xdir','reverse')
set (ax,'LineWidth',1)
hold on
%Plot pyrogenic model and unceratinty
plot (Age/1000,pCO2_min-232,'LineStyle','-','Color',[0.8500 0.3250 0.0980],'LineWidth',.75);
hold on
plot (Age/1000,pCO2_max-232,'LineStyle','-','Color',[0.8500 0.3250 0.0980],'LineWidth',.75);
hold on
jbfill(Age'/1000,(pCO2_min-232)',(pCO2_max-232)',[0.9290 0.6940 0.1250],'none');
hold on
%Plot CO2 data
plot (CO2age/1000,CO2-202,'LineStyle','-','Color','k','Marker','.','MarkerEdgeColor','k','LineWidth',.75,'MarkerSize',10);
hold on
aa = errorbar(CO2age/1000,CO2-202,0.7,'CapSize',.2,'Marker','none','LineStyle','none','Color','k');
hold on
% Plot Bauska 2021 model ouput
plot (Age/1000,mCO2_mean-235,'LineStyle','-','Color',[0.6350 0.0780 0.1840],'LineWidth',2);
hold on
xlim([38500/1000 40000/1000])
ylim([-5 36])
ax.XColor = 'none';
ax.YColor = 'k';
xlabel('Age (kyr BP)','FontSize',15)
set(gca,'FontSize',15)
%ylabel('\Delta CO_2 (ppm)','FontSize',15)
set(gca,'YTickLabel', [])

%modeled and ice core d13C-CO2 data
box off
axes('Position',[.39, .33, .27, .2])
set(gca,'Color','None')
ax = gca;
set (ax,'Xdir','reverse')
set (ax,'LineWidth',1)
hold on
% Plot pyrogenic model and unceratinty
plot (Age/1000,p13C_min+6.35,'LineStyle','-','Color',[0.8500 0.3250 0.0980],'LineWidth',.75);
hold on
plot (Age/1000,p13C_max+6.35,'LineStyle','-','Color',[0.8500 0.3250 0.0980],'LineWidth',.75);
hold on
jbfill(Age'/1000,(p13C_min+6.35)',(p13C_max+6.35)',[0.9290 0.6940 0.1250],'none');
hold on
% Plot CO2 data
plot ((d13Cage-150)/1000,d13C+6.5,'LineStyle','-','Color','k','Marker','.','MarkerEdgeColor','k','LineWidth',1,'MarkerSize',10);
hold on
aaa = errorbar((d13Cage-150)/1000,d13C+6.5,0.02,'CapSize',.2,'Marker','none','LineStyle','none','Color','k');
hold on
% Plot Bauska 2021 model ouput
plot (Age/1000,m13C_mean+6.37,'LineStyle','-','Color',[0.6350 0.0780 0.1840],'LineWidth',2);
hold on
xlim([38500/1000 40000/1000])
ylim([-0.5 0.15])
ax.XColor = 'k';
ax.YColor = 'k';
%ylabel(['\Delta \delta^1^3C-CO_2 ( ',char(8240),')'],'FontSize',15)
xlabel('Age (kyr BP)','FontSize',15)
set(gca,'FontSize',15)
set(gca,'YTickLabel', [])

%Plot histogram
box off
axes('Position',[.39, .065, .27, .2])
set(gca,'Color','None')
ax = gca;
set (ax,'LineWidth',1)
hold on
histogram(H4diff_data, 'BinWidth', 1,'Normalization','probability','FaceColor','k') 
histogram(H4diff, 'BinWidth', 1,'Normalization','probability','FaceColor',[0.9290 0.6940 0.1250]) 
histogram(H4diff_baseline, 'BinWidth', 1,'Normalization','probability','FaceColor',[0.6350 0.0780 0.1840]) 
xlabel('HE4 \Delta CO_2 (ppm)','FontSize',15)
%ylabel('Probability','FontSize',15)
ax.XColor = 'k';
ax.YColor = 'k';
xlim([0 30])
ylim([0 0.2])
set(gca,'FontSize',15)
set(gca,'YTickLabel', [])


% Lastly plot H1
%CFA CH4 record
box off
axes('Position',[.7, .77, .27, .18])
set(gca,'Color','None')
ax = gca;
set (ax,'Xdir','reverse')
set (ax,'LineWidth',1)
hold on
plot (GasAge/1000,CFA_CH4,'LineWidth',1.5,'Color','b');
hold on
xlim([15500/1000 17000/1000])
ylim([395 480])
ax.XColor = 'None';
ax.YColor = 'k';
%ylabel('[CH_4] (ppb)','FontSize',15)
set(gca,'FontSize',15)
set(gca,'YTickLabel', [])

%Modeled and ice core CO2 data
box off
axes('Position',[.7, .55, .27, .2])
set(gca,'Color','None')
ax = gca;
set (ax,'Xdir','reverse')
set (ax,'LineWidth',1)
hold on
%Plot pyrogenic model and unceratinty
plot (Age/1000,pCO2_min-239,'LineStyle','-','Color',[0.8500 0.3250 0.0980],'LineWidth',.75);
hold on
plot (Age/1000,pCO2_max-239,'LineStyle','-','Color',[0.8500 0.3250 0.0980],'LineWidth',.75);
hold on
jbfill(Age'/1000,(pCO2_min-239)',(pCO2_max-239)',[0.9290 0.6940 0.1250],'none');
hold on
%Plot CO2 data
plot (CO2age/1000,CO2-205,'LineStyle','-','Color','k','Marker','.','MarkerEdgeColor','k','LineWidth',.75,'MarkerSize',10);
hold on
aa = errorbar(CO2age/1000,CO2-205,0.7,'CapSize',.2,'Marker','none','LineStyle','none','Color','k');
hold on
% Plot Bauska 2021 model ouput
plot (Age/1000,mCO2_mean-238,'LineStyle','-','Color',[0.6350 0.0780 0.1840],'LineWidth',2);
hold on
xlim([15500/1000 17000/1000])
ylim([-5 36])
ax.XColor = 'none';
ax.YColor = 'k';
xlabel('Age (kyr BP)','FontSize',15)
set(gca,'FontSize',15)
%ylabel('\Delta CO_2 (ppm)','FontSize',15)
set(gca,'YTickLabel', [])

%modeled and ice core d13C-CO2 data
box off
axes('Position',[.7, .33, .27, .2])
set(gca,'Color','None')
ax = gca;
set (ax,'Xdir','reverse')
set (ax,'LineWidth',1)
hold on
% Plot pyrogenic model and unceratinty
plot (Age/1000,p13C_min+6.42,'LineStyle','-','Color',[0.8500 0.3250 0.0980],'LineWidth',.75);
hold on
plot (Age/1000,p13C_max+6.42,'LineStyle','-','Color',[0.8500 0.3250 0.0980],'LineWidth',.75);
hold on
jbfill(Age'/1000,(p13C_min+6.42)',(p13C_max+6.42)',[0.9290 0.6940 0.1250],'none');
hold on
% Plot CO2 data
plot ((d13Cage-150)/1000,d13C+6.5,'LineStyle','-','Color','k','Marker','.','MarkerEdgeColor','k','LineWidth',1,'MarkerSize',10);
hold on
aaa = errorbar((d13Cage-150)/1000,d13C+6.5,0.02,'CapSize',.2,'Marker','none','LineStyle','none','Color','k');
hold on
% Plot Bauska 2021 model ouput
plot (Age/1000,m13C_mean+6.4,'LineStyle','-','Color',[0.6350 0.0780 0.1840],'LineWidth',2);
hold on
xlim([15500/1000 17000/1000])
ylim([-0.5 0.15])
ax.XColor = 'k';
ax.YColor = 'k';
%ylabel(['\Delta \delta^1^3C-CO_2 ( ',char(8240),')'],'FontSize',15)
xlabel('Age (kyr BP)','FontSize',15)
set(gca,'FontSize',15)
set(gca,'YTickLabel', [])

%Plot histogram
box off
axes('Position',[.7, .065, .27, .2])
set(gca,'Color','None')
ax = gca;
set (ax,'LineWidth',1)
hold on
histogram(H1diff_data, 'BinWidth', 1,'Normalization','probability','FaceColor','k') 
histogram(H1diff, 'BinWidth', 1,'Normalization','probability','FaceColor',[0.9290 0.6940 0.1250]) 
histogram(H1diff_baseline, 'BinWidth', 1,'Normalization','probability','FaceColor',[0.6350 0.0780 0.1840]) 
xlabel('HE1 \Delta CO_2 (ppm)','FontSize',15)
%ylabel('Probability','FontSize',15)
ax.XColor = 'k';
ax.YColor = 'k';
xlim([0 30])
ylim([0 0.2])
set(gca,'FontSize',15)
set(gca,'YTickLabel', [])

%Label boxes 
annotation('textbox',[.94 .85 .1 .1],'String','(a)','EdgeColor','none','FontSize',20,'Color','k')
annotation('textbox',[.94 .65 .1 .1],'String','(b)','EdgeColor','none','FontSize',20,'Color','k')
annotation('textbox',[.94 .43 .1 .1],'String','(c)','EdgeColor','none','FontSize',20,'Color','k')
annotation('textbox',[.94 .16 .1 .1],'String','(d)','EdgeColor','none','FontSize',20,'Color','k')
% annotation('textbox',[.39 .55 .1 .1],'String','(e)','EdgeColor','none','FontSize',17,'Color',[.3 .3 .3])
% annotation('textbox',[.70 .55 .1 .1],'String','(f)','EdgeColor','none','FontSize',17,'Color',[.3 .3 .3])
% annotation('textbox',[.08 .25 .1 .1],'String','(g)','EdgeColor','none','FontSize',17,'Color',[.3 .3 .3])
% annotation('textbox',[.39 .25 .1 .1],'String','(h)','EdgeColor','none','FontSize',17,'Color',[.3 .3 .3])
% annotation('textbox',[.70 .25 .1 .1],'String','(i)','EdgeColor','none','FontSize',17,'Color',[.3 .3 .3])

%Label columns
annotation('textbox',[.12 .89 .1 .1],'String','Heinrich Event 5','EdgeColor','none','FontSize',18,'FontWeight','bold','Color','k')
annotation('textbox',[.44 .89 .1 .1],'String','Heinrich Event 4','EdgeColor','none','FontSize',18,'FontWeight','bold','Color','k')
annotation('textbox',[.756 .89 .1 .1],'String','Heinrich Event 1','EdgeColor','none','FontSize',18,'FontWeight','bold','Color','k')

